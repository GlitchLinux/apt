# CryptoCloud 0.1 (beta)

Encrypted media vaults for Debian and Ubuntu: a gocryptfs master storage holding
individual LUKS2 vault images, a mobile-friendly web app, and a PyQt5 desktop app.

## Install

    tar xzf cryptocloud-0.1.tar.gz
    cd cryptocloud-0.1
    sudo ./install.sh

Then start **CryptoCloud** from the application menu (or run `cryptocloud-gui`).
The first-run wizard offers three modes:

- **Offline on this computer**: vaults on a folder, an external disk or a
  /dev/loop device. Disks are remembered by filesystem UUID and mounted
  automatically at /mnt/cryptocloud-mount when CryptoCloud starts and finds them
  unmounted (loop devices are re-attached from their image file). Works in any
  browser at http://cryptocloud.localhost, without internet.
- **Web server backend**: installs into /var/www/<domain>/ behind Apache, with
  an optional Let's Encrypt certificate.
- **Connect to an existing server**: use a CryptoCloud running elsewhere.

Headless servers can skip the GUI (the master password is read from stdin):

    read -rsp 'Master password: ' P; echo
    printf '%s\n' "$P" | sudo cryptocloud-setup web --domain example.com --certbot
    unset P

## Files

| What | Where |
|---|---|
| Configuration (mode, URL, storage pointer) | /etc/cryptocloud/cryptocloud.conf |
| Root helper / setup | /usr/local/sbin/cryptocloud-helper, cryptocloud-setup |
| Web backend + front end | /opt/cryptocloud (service: cryptocloud.service) |
| Desktop app | /usr/local/bin/cryptocloud-gui |
| Auto-lock setting | /var/lib/cryptocloud/settings.json |

## Uninstall

    sudo ./uninstall.sh

Program files are removed; encrypted vault data is never deleted.

## Requirements

Debian 11+ or Ubuntu 22.04+, systemd, Python 3.9+. The storage must be on a
Linux filesystem (ext4, xfs, btrfs or f2fs) because vault images are sparse files.
