/* CryptoCloud front end - vanilla JS, no dependencies */
"use strict";

const $ = (id) => document.getElementById(id);
const enc = encodeURIComponent;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const joinPath = (a, b) => (a ? `${a}/${b}` : b);
const randId = () => Array.from(crypto.getRandomValues(new Uint8Array(12)),
  (b) => b.toString(16).padStart(2, "0")).join("");

const S = {
  label: null, path: "", entries: [], media: [], space: null, vaults: null,
  selecting: false, selected: new Set(), vIdx: -1, uploading: false,
  dlgSubmit: null, created: null,
};

class AuthError extends Error {}

/* ---------- API ---------- */
function detail(d) {
  if (!d) return "";
  if (typeof d.detail === "string") return d.detail;
  if (Array.isArray(d.detail)) return "Some fields are missing or invalid";
  return d.error || "";
}

async function api(method, url, body) {
  const opt = { method, credentials: "same-origin", cache: "no-store", headers: {} };
  if (body !== undefined) {
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  const res = await fetch(url, opt);
  let data = null;
  try { data = await res.json(); } catch (_) { /* empty body */ }
  if (res.status === 401 && !url.startsWith("/api/login")) {
    toLock(detail(data) === "CryptoCloud is locked" ? "CryptoCloud is locked" : "Your session ended. Sign in again.");
    throw new AuthError(detail(data) || "Sign in required");
  }
  if (!res.ok) {
    const e = new Error(detail(data) || `Request failed (${res.status})`);
    e.status = res.status;
    throw e;
  }
  // Every real action resets the server's auto-lock timer; mirror that locally
  if (!url.startsWith("/api/autolock") && url !== "/api/state") alBump();
  return data;
}

const vurl = (ep, params = {}) =>
  `/api/vaults/${enc(S.label)}/${ep}?` + new URLSearchParams(params);

/* ---------- Formatting + feedback ---------- */
function fmtSize(b) {
  if (b < 1024) return `${b} B`;
  const u = ["KB", "MB", "GB", "TB"];
  let i = -1;
  do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
  return `${b < 10 ? b.toFixed(1) : Math.round(b)} ${u[i]}`;
}
const fmtMB = (mb) => (mb >= 1024 ? `${(mb / 1024).toFixed(mb % 1024 ? 1 : 0)} GB` : `${mb} MB`);

let toastTimer;
function toast(msg, err = false) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.toggle("err", err);
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2800);
}
function fail(e) {
  if (e instanceof AuthError) return;
  toast(e.message || String(e), true);
}

/* ---------- Screens + history ---------- */
function show(id) {
  for (const s of ["lock", "vaults", "browser"]) $(s).hidden = s !== id;
  window.scrollTo(0, 0);
}

function toLock(hint) {
  AL.deadline = 0;
  $("autolockBar").hidden = true;
  ED.saved = false; ED.dirty = false; closeEditorUI();
  closeViewerUI();
  closeDialog(false);
  exitSelect();
  S.label = null; S.entries = []; S.media = [];
  show("lock");
  $("lockHint").textContent = hint || "Enter the master password";
  $("loginMsg").textContent = "";
  $("password").value = "";
  history.replaceState({ screen: "vaults" }, "");
  setTimeout(() => $("password").focus(), 60);
}

function nav(st, replace = false) {
  history[replace ? "replaceState" : "pushState"](st, "");
  return route(st);
}
window.addEventListener("popstate", (e) => {
  if (!$("lock").hidden) return;
  route(e.state || { screen: "vaults" });
});

async function route(st) {
  // Leaving the editor via the back button: protect unsaved changes
  if (!$("editor").hidden && !st.editor) {
    if (ED.dirty) {
      history.pushState(ED.state, "");
      requestCloseEditor();
      return;
    }
    closeEditorUI();
  }
  try {
    if (st.screen === "browser") {
      if (S.label !== st.label || S.path !== st.path || $("browser").hidden) {
        await loadDir(st.label, st.path);
      }
      show("browser");
      if (st.viewer != null && S.media.length) {
        openViewerUI(Math.min(st.viewer, S.media.length - 1));
      } else {
        closeViewerUI();
      }
      return;
    }
    closeViewerUI();
    await showVaults();
  } catch (e) {
    if (e instanceof AuthError) return;
    if (e.status === 403 || e.status === 404) {
      toast(e.message, true);
      history.replaceState({ screen: "vaults" }, "");
      await showVaults().catch(fail);
      return;
    }
    fail(e);
  }
}

/* ---------- Dialog ---------- */
let dlgResolve = null;

function ask({ title, lead = "", fields = [], ok = "OK", danger = false, busy = "Working…", submit }) {
  return new Promise((resolve) => {
    const dlg = $("dialog");
    const box = $("dialogFields");
    const okBtn = $("dialogOk");
    const msg = $("dialogMsg");
    $("dialogTitle").textContent = title;
    $("dialogLead").textContent = lead;
    $("dialogLead").hidden = !lead;
    msg.textContent = "";
    msg.className = "msg";
    box.replaceChildren();
    for (const f of fields) {
      const wrap = document.createElement("label");
      wrap.className = "field";
      const sp = document.createElement("span");
      sp.textContent = f.label;
      wrap.append(sp);
      let el;
      if (f.type === "select") {
        el = document.createElement("select");
        for (const [v, t] of f.options) {
          const o = document.createElement("option");
          o.value = v; o.textContent = t;
          el.append(o);
        }
      } else {
        el = document.createElement("input");
        el.type = f.type || "text";
        el.autocomplete = f.autocomplete || "off";
        el.setAttribute("autocapitalize", f.autocapitalize || "off");
        el.spellcheck = false;
        if (f.placeholder) el.placeholder = f.placeholder;
      }
      el.name = f.name;
      if (f.value != null) el.value = f.value;
      wrap.append(el);
      if (f.hint) {
        const sm = document.createElement("small");
        sm.textContent = f.hint;
        wrap.append(sm);
      }
      box.append(wrap);
    }
    okBtn.textContent = ok;
    okBtn.hidden = false;
    okBtn.className = `tb ${danger ? "danger" : "accent"}`;
    okBtn.disabled = false;
    $("dialogCancel").disabled = false;
    if (dlgResolve) dlgResolve(false);
    dlgResolve = resolve;

    S.dlgSubmit = async () => {
      const vals = {};
      for (const el of box.querySelectorAll("input, select")) vals[el.name] = el.value;
      okBtn.disabled = true;
      $("dialogCancel").disabled = true;
      msg.className = "msg info";
      msg.textContent = busy;
      try {
        if (submit) await submit(vals);
        closeDialog(true);
      } catch (e) {
        msg.className = "msg";
        msg.textContent = e instanceof AuthError ? "" : e.message;
        okBtn.disabled = false;
        $("dialogCancel").disabled = false;
      }
    };

    dlg.showModal();
    const first = box.querySelector("input, select");
    (first || okBtn).focus();
  });
}

function closeDialog(result) {
  const dlg = $("dialog");
  if (dlg.open) dlg.close();
  S.dlgSubmit = null;
  if (dlgResolve) {
    const r = dlgResolve;
    dlgResolve = null;
    r(result);
  }
}

/* Action sheet: resolves with the chosen value, or false on cancel */
function pick(title, lead, options) {
  return new Promise((resolve) => {
    $("dialogTitle").textContent = title;
    $("dialogLead").textContent = lead || "";
    $("dialogLead").hidden = !lead;
    $("dialogMsg").textContent = "";
    const box = $("dialogFields");
    box.replaceChildren();
    const wrap = document.createElement("div");
    wrap.className = "pick";
    for (const o of options) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = `tb wide${o.danger ? " danger" : ""}`;
      b.textContent = o.label;
      b.addEventListener("click", () => closeDialog(o.value));
      wrap.append(b);
    }
    box.append(wrap);
    $("dialogOk").hidden = true;
    $("dialogCancel").disabled = false;
    if (dlgResolve) dlgResolve(false);
    dlgResolve = resolve;
    S.dlgSubmit = null;
    $("dialog").showModal();
    wrap.firstChild.focus();
  });
}

$("dialogForm").addEventListener("submit", (e) => {
  e.preventDefault();
  if (S.dlgSubmit && !$("dialogOk").disabled) S.dlgSubmit();
});
$("dialogCancel").addEventListener("click", () => closeDialog(false));
$("dialog").addEventListener("cancel", (e) => {
  e.preventDefault();
  if (!$("dialogCancel").disabled) closeDialog(false);
});

/* ---------- Lock screen ---------- */
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const pw = $("password").value;
  if (!pw) return;
  const btn = $("loginBtn");
  btn.disabled = true;
  btn.textContent = "Unlocking…";
  $("loginMsg").textContent = "";
  try {
    await api("POST", "/api/login", { password: pw });
    $("password").value = "";
    await nav({ screen: "vaults" }, true);
    alPoll();
  } catch (err) {
    $("loginMsg").textContent = err.message;
    const lock = $("lock");
    lock.classList.remove("shake");
    void lock.offsetWidth;
    lock.classList.add("shake");
    $("password").select();
  } finally {
    btn.disabled = false;
    btn.textContent = "Unlock";
  }
});

/* ---------- Vault list ---------- */
async function showVaults() {
  exitSelect();
  const d = await api("GET", "/api/vaults");
  S.vaults = d;
  S.label = null;
  show("vaults");
  const pct = d.budget_mb ? Math.min(100, (d.used_mb / d.budget_mb) * 100) : 0;
  $("budgetFill").style.width = `${pct}%`;
  $("budgetText").textContent = `${fmtMB(d.used_mb)} of ${fmtMB(d.budget_mb)}`;
  const ul = $("vaultList");
  ul.replaceChildren();
  $("vaultsEmpty").hidden = d.vaults.length > 0;
  for (const v of d.vaults) {
    const li = document.createElement("li");
    const b = document.createElement("button");
    b.type = "button";
    b.className = "vault";
    const [cls, text] = v.unlocked ? ["on", "Unlocked"] : v.open ? ["mid", "Mounted"] : ["", "Locked"];
    const glyph = document.createElement("span");
    glyph.className = "vault-glyph";
    glyph.setAttribute("aria-hidden", "true");
    glyph.textContent = v.unlocked ? "🔓" : "🔐";
    const main = document.createElement("span");
    main.className = "vault-main";
    const name = document.createElement("span");
    name.className = "vault-name";
    name.textContent = v.label;
    const meta = document.createElement("span");
    meta.className = "vault-meta";
    meta.textContent = `up to ${v.size}`;
    main.append(name, meta);
    const pill = document.createElement("span");
    pill.className = `pill ${cls}`;
    pill.textContent = text;
    b.append(glyph, main, pill);
    b.addEventListener("click", () => openVault(v));
    const del = document.createElement("button");
    del.type = "button";
    del.className = "tb danger vault-del";
    del.setAttribute("aria-label", `Actions for ${v.label}`);
    del.textContent = "⋯";
    del.className = "tb vault-del";
    del.addEventListener("click", () => vaultMenu(v));
    li.className = "vault-row";
    li.append(b, del);
    ul.append(li);
  }
}

async function openVault(v) {
  if (v.unlocked) return nav({ screen: "browser", label: v.label, path: "" });
  const ok = await ask({
    title: `Unlock ${v.label}`,
    lead: "Enter the password for this vault.",
    fields: [{ name: "password", label: "Vault password", type: "password" }],
    ok: "Unlock",
    busy: "Unlocking…",
    submit: async (f) => {
      if (!f.password) throw new Error("Enter the vault password");
      await api("POST", `/api/vaults/${enc(v.label)}/open`, { password: f.password });
    },
  });
  if (ok) await nav({ screen: "browser", label: v.label, path: "" });
}

const sizeToMB = (tok) => {
  const m = /^(\d+)(MB|GB)$/.exec(tok || "");
  return m ? Number(m[1]) * (m[2] === "GB" ? 1024 : 1) : 0;
};

async function vaultMenu(v) {
  const choice = await pick(v.label, `Maximum size ${v.size}`, [
    { value: "grow", label: "Grow vault" },
    { value: "passwd", label: "Change password" },
    { value: "delete", label: "Delete vault", danger: true },
  ]);
  if (choice === "grow") growVault(v);
  else if (choice === "passwd") changeVaultPw(v);
  else if (choice === "delete") deleteVault(v);
}

async function growVault(v) {
  const d = S.vaults || { budget_mb: 0, used_mb: 0 };
  const cur = sizeToMB(v.size);
  const room = d.budget_mb - d.used_mb + cur;
  if (room <= cur) { toast("There is no room left to grow this vault within 100 GB", true); return; }
  const ok = await ask({
    title: `Grow ${v.label}`,
    lead: `Currently up to ${v.size}. The vault is closed and reopened for a moment; files are kept. Disk space is still only used as files are added.`,
    fields: [
      { name: "size", label: "New maximum size", placeholder: "e.g. 20MB or 75GB",
        hint: `Larger than ${v.size}, at most ${fmtMB(room)}.` },
      { name: "password", label: "Vault password", type: "password" },
    ],
    ok: "Grow vault",
    busy: "Growing the vault…",
    submit: async (f) => {
      const size = parseSize(f.size);
      if (!size) throw new Error("Write the size as a number with MB or GB, for example 20MB or 75GB");
      if (size.mb <= cur) throw new Error(`The new size must be larger than ${v.size}`);
      if (size.mb > room) throw new Error(`At most ${fmtMB(room)} fits within the 100 GB allocation`);
      if (!f.password) throw new Error("Enter the vault password");
      const r = await api("POST", `/api/vaults/${enc(v.label)}/grow`, { size: size.tok, password: f.password });
      S.created = r.size;
    },
  });
  if (ok) {
    toast(`${v.label} can now hold up to ${S.created}`);
    await showVaults().catch(fail);
  }
}

async function changeVaultPw(v) {
  const ok = await ask({
    title: `Change password for ${v.label}`,
    lead: "The files stay as they are; only the key that unlocks them changes.",
    fields: [
      { name: "old", label: "Current password", type: "password" },
      { name: "new", label: "New password", type: "password", autocomplete: "new-password",
        hint: "At least 8 characters. A lost password cannot be recovered." },
      { name: "confirm", label: "Repeat new password", type: "password", autocomplete: "new-password" },
    ],
    ok: "Change password",
    busy: "Changing the password, this takes a few seconds…",
    submit: async (f) => {
      if (!f.old) throw new Error("Enter the current password");
      if (f.new.length < 8) throw new Error("The new password needs at least 8 characters");
      if (f.new !== f.confirm) throw new Error("The new passwords do not match");
      await api("POST", `/api/vaults/${enc(v.label)}/passwd`, { old: f.old, new: f.new });
    },
  });
  if (ok) toast(`Password for ${v.label} changed`);
}

async function deleteVault(v) {
  const ok = await ask({
    title: `Delete ${v.label}?`,
    lead: `Every file in this vault is destroyed for good and its ${v.size} allocation is freed. This cannot be undone.`,
    fields: [
      { name: "password", label: "Vault password", type: "password" },
      { name: "confirm", label: `Type ${v.label} to confirm`, placeholder: v.label },
    ],
    ok: "Delete vault",
    danger: true,
    busy: "Deleting the vault…",
    submit: async (f) => {
      if (!f.password) throw new Error("Enter the vault password");
      if (f.confirm.trim() !== v.label) throw new Error(`Type ${v.label} exactly to confirm`);
      await api("POST", `/api/vaults/${enc(v.label)}/destroy`,
        { password: f.password, confirm: f.confirm.trim() });
    },
  });
  if (ok) {
    toast(`${v.label} deleted`);
    await showVaults().catch(fail);
  }
}

function parseSize(txt) {
  const m = /^\s*(\d+)\s*(MB|GB|M|G)\s*$/i.exec(txt || "");
  if (!m) return null;
  const n = Number(m[1]);
  const giga = m[2][0].toUpperCase() === "G";
  return { tok: `${n}${giga ? "G" : "M"}`, mb: n * (giga ? 1024 : 1) };
}
const MIN_VAULT_MB = 2;

$("newVaultBtn").addEventListener("click", async () => {
  const d = S.vaults || { budget_mb: 0, used_mb: 0 };
  const free = d.budget_mb - d.used_mb;
  if (free < MIN_VAULT_MB) { toast("The 100 GB allocation is used up", true); return; }
  const ok = await ask({
    title: "New vault",
    lead: `A separate encrypted disk with its own password. Disk space is only used as files are added. ${fmtMB(free)} left to allocate.`,
    fields: [
      { name: "label", label: "Name", placeholder: "photos", hint: "Lowercase letters, digits and dashes" },
      { name: "size", label: "Maximum size", value: free >= 10240 ? "10GB" : `${free}MB`,
        placeholder: "e.g. 3MB, 500MB or 10GB",
        hint: `Any size from ${MIN_VAULT_MB}MB to ${fmtMB(free).replace(" ", "")}. About 1 MB goes to the encryption header.` },
      { name: "password", label: "Vault password", type: "password", autocomplete: "new-password",
        hint: "At least 8 characters. A lost password cannot be recovered." },
      { name: "confirm", label: "Repeat password", type: "password", autocomplete: "new-password" },
    ],
    ok: "Create vault",
    busy: "Creating the vault, this takes about 10 seconds…",
    submit: async (f) => {
      const label = f.label.trim();
      if (!/^[a-z0-9][a-z0-9-]{0,31}$/.test(label)) throw new Error("Use lowercase letters, digits and dashes (max 32)");
      const size = parseSize(f.size);
      if (!size) throw new Error("Write the size as a number with MB or GB, for example 3MB or 10GB");
      if (size.mb < MIN_VAULT_MB) throw new Error(`The smallest vault is ${MIN_VAULT_MB}MB`);
      if (size.mb > free) throw new Error(`Only ${fmtMB(free)} is left to allocate`);
      if (f.password.length < 8) throw new Error("The password needs at least 8 characters");
      if (f.password !== f.confirm) throw new Error("The passwords do not match");
      await api("POST", "/api/vaults", { label, size: size.tok, password: f.password });
      S.created = label;
    },
  });
  if (ok) {
    toast(`Vault ${S.created} created`);
    await nav({ screen: "browser", label: S.created, path: "" });
  }
});

$("lockBtn").addEventListener("click", async () => {
  const ok = await ask({
    title: "Lock CryptoCloud?",
    lead: "Every vault is closed and all devices are signed out. The master password is needed to get back in.",
    ok: "Lock",
    danger: true,
    busy: "Locking…",
    submit: () => api("POST", "/api/lock"),
  });
  if (ok) toLock("CryptoCloud is locked");
});

/* ---------- Folder browser ---------- */
const GLYPH = { dir: "📁", video: "🎞️", audio: "🎵", image: "🖼️", text: "📝", file: "📄" };

async function loadDir(label, path) {
  const prev = S.label;
  S.label = label;
  let d;
  try {
    d = await api("GET", vurl("list", { path }));
  } catch (e) {
    S.label = prev;
    throw e;
  }
  S.path = d.path;
  S.entries = d.entries;
  S.space = d.space;
  S.media = d.entries.filter((e) => e.kind === "image" || e.kind === "video" || e.kind === "audio");
  exitSelect();
  renderCrumbs();
  renderGrid();
}

function renderCrumbs() {
  const c = $("crumbs");
  c.replaceChildren();
  const parts = S.path ? S.path.split("/") : [];
  const mk = (text, path) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = text;
    b.addEventListener("click", () => {
      if (path !== S.path) nav({ screen: "browser", label: S.label, path });
    });
    return b;
  };
  c.append(mk(S.label, ""));
  parts.forEach((p, i) => {
    const s = document.createElement("span");
    s.className = "sep";
    s.textContent = "/";
    c.append(s, mk(p, parts.slice(0, i + 1).join("/")));
  });
  c.scrollLeft = c.scrollWidth;
}

function addGlyph(t, e) {
  const g = document.createElement("span");
  g.className = "glyph";
  g.textContent = GLYPH[e.kind] || "📄";
  t.prepend(g);
  if (!e.dir) {
    const x = document.createElement("span");
    x.className = "ext";
    x.textContent = (e.name.includes(".") ? e.name.split(".").pop() : "file").slice(0, 8);
    g.after(x);
  }
}

function renderGrid() {
  const g = $("grid");
  g.replaceChildren();
  $("dirEmpty").hidden = S.entries.length > 0;
  for (const e of S.entries) {
    const t = document.createElement("div");
    t.className = `tile${e.dir ? " folder" : ""}`;
    t.tabIndex = 0;
    t.setAttribute("role", "button");
    t.setAttribute("aria-label", e.name);
    const full = joinPath(S.path, e.name);
    if (e.kind === "image" || e.kind === "video") {
      t.classList.add("media");
      const img = document.createElement("img");
      img.className = "thumb";
      img.loading = "lazy";
      img.decoding = "async";
      img.alt = "";
      img.src = vurl("thumb", { path: full });
      img.addEventListener("error", () => { img.remove(); addGlyph(t, e); });
      t.append(img);
      if (e.kind === "video") {
        const p = document.createElement("span");
        p.className = "play";
        p.textContent = "▶";
        t.append(p);
      }
    } else {
      addGlyph(t, e);
    }
    const l = document.createElement("span");
    l.className = "label";
    l.textContent = e.name;
    const meta = document.createElement("span");
    meta.className = "meta";
    if (e.dir) {
      meta.textContent = "Folder";
    } else {
      const top = document.createElement("span");
      top.textContent = fmtSize(e.size);
      const date = document.createElement("span");
      date.textContent = new Date(e.mtime * 1000).toLocaleDateString(undefined,
        { year: "numeric", month: "short", day: "numeric" });
      meta.append(top, document.createElement("br"), date);
    }
    t.append(l, meta);
    bindTile(t, e);
    g.append(t);
  }
}

function bindTile(t, e) {
  let timer = null;
  let long = false;
  let sx = 0;
  let sy = 0;
  const cancel = () => { clearTimeout(timer); timer = null; };
  t.addEventListener("pointerdown", (ev) => {
    long = false;
    sx = ev.clientX; sy = ev.clientY;
    timer = setTimeout(() => {
      long = true;
      if (!S.selecting) enterSelect();
      toggleSel(e.name, t);
      if (navigator.vibrate) navigator.vibrate(15);
    }, 500);
  });
  t.addEventListener("pointermove", (ev) => {
    if (Math.abs(ev.clientX - sx) > 10 || Math.abs(ev.clientY - sy) > 10) cancel();
  });
  t.addEventListener("pointerup", cancel);
  t.addEventListener("pointercancel", cancel);
  t.addEventListener("pointerleave", cancel);
  t.addEventListener("contextmenu", (ev) => ev.preventDefault());
  t.addEventListener("click", () => {
    if (long) { long = false; return; }
    if (S.selecting) { toggleSel(e.name, t); return; }
    activate(e);
  });
  t.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); t.click(); }
  });
}

function activate(e) {
  const full = joinPath(S.path, e.name);
  if (e.dir) return nav({ screen: "browser", label: S.label, path: full });
  if (e.kind === "text") return openEditor(e.name, false);
  const i = S.media.findIndex((m) => m.name === e.name);
  if (i >= 0) return nav({ screen: "browser", label: S.label, path: S.path, viewer: i });
  location.href = vurl("file", { path: full, download: 1 });
}

/* Icon / list view, remembered per device */
let listView = false;
try { listView = localStorage.getItem("cc-view") === "list"; } catch (_) { /* private mode */ }
function applyView() {
  $("grid").classList.toggle("list", listView);
  const b = $("viewBtn");
  b.textContent = listView ? "▦" : "☰";
  b.setAttribute("aria-label", listView ? "Show as icons" : "Show as list");
}
$("viewBtn").addEventListener("click", () => {
  listView = !listView;
  try { localStorage.setItem("cc-view", listView ? "list" : "icons"); } catch (_) { /* ignore */ }
  applyView();
});
applyView();

/* Selection */
function enterSelect() {
  S.selecting = true;
  S.selected.clear();
  $("grid").classList.add("selecting");
  $("browseBar").hidden = true;
  $("selectBar").hidden = false;
  $("selectBtn").textContent = "Done";
  updateSel();
}
function exitSelect() {
  S.selecting = false;
  S.selected.clear();
  $("grid").classList.remove("selecting");
  for (const t of $("grid").querySelectorAll(".tile.sel")) t.classList.remove("sel");
  $("browseBar").hidden = false;
  $("selectBar").hidden = true;
  $("selectBtn").textContent = "Select";
}
function toggleSel(name, t) {
  if (S.selected.has(name)) { S.selected.delete(name); t.classList.remove("sel"); }
  else { S.selected.add(name); t.classList.add("sel"); }
  updateSel();
}
function updateSel() {
  const n = S.selected.size;
  $("selCount").textContent = n ? `${n} selected` : "Tap items to select";
  $("selDelete").disabled = !n;
  $("selRename").disabled = n !== 1;
}
$("selectBtn").addEventListener("click", () => (S.selecting ? exitSelect() : enterSelect()));
$("selDelete").addEventListener("click", () => deleteNames([...S.selected]));
$("selRename").addEventListener("click", () => renameName([...S.selected][0]));

function checkNewName(n) {
  if (!n || n.includes("/") || n.startsWith(".")) throw new Error("Names cannot be empty, contain / or start with a dot");
}

async function deleteNames(names) {
  if (!names.length) return false;
  const what = names.length === 1 ? `“${names[0]}”` : `${names.length} items`;
  const ok = await ask({
    title: `Delete ${what}?`,
    lead: "Deleted files cannot be recovered.",
    ok: "Delete",
    danger: true,
    busy: "Deleting…",
    submit: () => api("POST", vurl("delete"), { paths: names.map((n) => joinPath(S.path, n)) }),
  });
  if (ok) {
    toast(names.length === 1 ? "Deleted" : `Deleted ${names.length} items`);
    await loadDir(S.label, S.path).catch(fail);
  }
  return ok;
}

async function renameName(name) {
  const ok = await ask({
    title: "Rename",
    fields: [{ name: "name", label: "New name", value: name, autocapitalize: "sentences" }],
    ok: "Rename",
    busy: "Renaming…",
    submit: async (f) => {
      const n = f.name.trim();
      checkNewName(n);
      if (n !== name) await api("POST", vurl("rename"), { path: joinPath(S.path, name), name: n });
    },
  });
  if (ok) await loadDir(S.label, S.path).catch(fail);
}

$("mkdirBtn").addEventListener("click", async () => {
  const what = await pick("Create new", "", [
    { value: "folder", label: "Folder" },
    { value: "text", label: "Text file" },
  ]);
  if (what === "folder") await newFolder();
  else if (what === "text") await newTextFile();
});

async function newFolder() {
  const ok = await ask({
    title: "New folder",
    fields: [{ name: "name", label: "Folder name", autocapitalize: "sentences" }],
    ok: "Create folder",
    busy: "Creating…",
    submit: async (f) => {
      const n = f.name.trim();
      checkNewName(n);
      await api("POST", vurl("mkdir"), { path: S.path, name: n });
    },
  });
  if (ok) await loadDir(S.label, S.path).catch(fail);
}

async function newTextFile() {
  const ok = await ask({
    title: "New text file",
    fields: [{ name: "name", label: "File name", value: "notes.txt" }],
    ok: "Create and edit",
    busy: "Opening…",
    submit: async (f) => {
      let n = f.name.trim();
      checkNewName(n);
      if (!n.includes(".")) n += ".txt";
      if (S.entries.some((e) => e.name === n)) throw new Error("A file with that name already exists");
      S.created = n;
    },
  });
  if (ok) openEditor(S.created, true);
}

$("closeVaultBtn").addEventListener("click", async () => {
  const label = S.label;
  const ok = await ask({
    title: `Close ${label}?`,
    lead: "The vault is unmounted on the server. Every device then needs its password again.",
    ok: "Close vault",
    danger: true,
    busy: "Closing…",
    submit: () => api("POST", `/api/vaults/${enc(label)}/close`),
  });
  if (ok) {
    toast(`${label} closed`);
    await nav({ screen: "vaults" });
  }
});

$("backBtn").addEventListener("click", () => {
  if (S.path) {
    nav({ screen: "browser", label: S.label, path: S.path.split("/").slice(0, -1).join("/") });
  } else {
    nav({ screen: "vaults" });
  }
});

/* ---------- Text editor ---------- */
const ED = { path: null, name: null, dirty: false, isNew: false, saved: false, state: null };

function setEdState(text, cls = "") {
  const e = $("edState");
  e.textContent = text;
  e.className = `ed-state${cls ? ` ${cls}` : ""}`;
}

async function openEditor(name, isNew) {
  const full = joinPath(S.path, name);
  let text = "";
  if (!isNew) {
    const e = S.entries.find((x) => x.name === name);
    if (e && e.size > 5 * 1024 * 1024) { toast("Files over 5 MB cannot be edited here", true); return; }
    let res;
    try {
      res = await fetch(vurl("file", { path: full }), { credentials: "same-origin", cache: "no-store" });
    } catch (_) {
      toast("The server cannot be reached right now", true);
      return;
    }
    if (res.status === 401) { toLock("Your session ended. Sign in again."); return; }
    if (!res.ok) { toast(`Could not open ${name}`, true); return; }
    try {
      text = new TextDecoder("utf-8", { fatal: true }).decode(await res.arrayBuffer());
    } catch (_) {
      toast("This file is not plain UTF-8 text", true);
      return;
    }
  }
  Object.assign(ED, {
    path: full, name, dirty: isNew, isNew, saved: false,
    state: { screen: "browser", label: S.label, path: S.path, editor: name },
  });
  $("edName").textContent = name;
  $("edText").value = text;
  setEdState(isNew ? "New file" : "", isNew ? "dirty" : "");
  $("editor").hidden = false;
  document.body.style.overflow = "hidden";
  history.pushState(ED.state, "");
  if (isNew) setTimeout(() => $("edText").focus(), 60);
}

function closeEditorUI() {
  if ($("editor").hidden) return;
  $("editor").hidden = true;
  $("edText").value = "";
  document.body.style.overflow = "";
  const reload = ED.saved;
  ED.dirty = false;
  ED.saved = false;
  ED.path = null;
  if (reload && S.label) loadDir(S.label, S.path).catch(fail);
}

async function saveEditor() {
  const btn = $("edSave");
  if (btn.disabled || !ED.path) return false;
  btn.disabled = true;
  setEdState("Saving…");
  try {
    const url = `/api/vaults/${enc(ED.state.label)}/save?` +
      new URLSearchParams({ path: ED.path, create: ED.isNew ? 1 : 0 });
    const res = await fetch(url, {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "text/plain; charset=utf-8" },
      body: $("edText").value,
    });
    let data = null;
    try { data = await res.json(); } catch (_) { /* none */ }
    if (res.status === 401) { toLock("Your session ended. Sign in again."); return false; }
    if (!res.ok) throw new Error(detail(data) || `Saving failed (${res.status})`);
    ED.dirty = false;
    ED.isNew = false;
    ED.saved = true;
    alBump();
    setEdState("Saved", "saved");
    return true;
  } catch (e) {
    setEdState("Not saved", "dirty");
    toast(e.message || "Saving failed", true);
    return false;
  } finally {
    btn.disabled = false;
  }
}

async function requestCloseEditor() {
  if (ED.dirty) {
    const c = await pick("Unsaved changes", `Save changes to ${ED.name} before closing?`, [
      { value: "save", label: "Save" },
      { value: "discard", label: "Discard changes", danger: true },
    ]);
    if (!c) return;
    if (c === "save" && !(await saveEditor())) return;
    ED.dirty = false;
  }
  if (history.state && history.state.editor) history.back();
  else closeEditorUI();
}

$("edClose").addEventListener("click", requestCloseEditor);
$("edSave").addEventListener("click", saveEditor);
$("edText").addEventListener("input", () => {
  if (!ED.dirty) { ED.dirty = true; setEdState("Unsaved", "dirty"); }
});
$("edText").addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); saveEditor(); }
});

/* ---------- Uploads (8 MB chunks, resumable per file) ---------- */
const CHUNK = 8 * 1024 * 1024;
$("uploadBtn").addEventListener("click", () => $("fileInput").click());
$("fileInput").addEventListener("change", () => {
  const files = [...$("fileInput").files];
  $("fileInput").value = "";
  if (files.length) uploadFiles(files);
});
window.addEventListener("beforeunload", (e) => {
  if (S.uploading || ED.dirty) { e.preventDefault(); e.returnValue = ""; }
});

async function uploadFiles(files) {
  if (S.uploading) { toast("An upload is already running", true); return; }
  S.uploading = true;
  const label = S.label;
  const path = S.path;
  const total = files.reduce((a, f) => a + f.size, 0);
  let done = 0;
  let okCount = 0;
  const w = $("uploadWidget");
  const fill = $("uploadFill");
  w.hidden = false;
  fill.className = "bar-fill busy";
  const upd = (i) => {
    const pct = total ? Math.floor((done / total) * 100) : 100;
    $("uploadText").textContent = files.length > 1 ? `Uploading ${i + 1} of ${files.length}` : `Uploading ${files[0].name}`;
    $("uploadPct").textContent = `${pct}%`;
    fill.style.width = `${pct}%`;
  };
  try {
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const id = randId();
      let off = 0;
      let tries = 0;
      upd(i);
      for (;;) {
        const end = Math.min(off + CHUNK, f.size);
        const url = `/api/vaults/${enc(label)}/upload?` +
          new URLSearchParams({ path, name: f.name, offset: off, total: f.size, id });
        let res;
        let data = null;
        try {
          res = await fetch(url, {
            method: "POST", credentials: "same-origin",
            headers: { "Content-Type": "application/octet-stream" },
            body: f.slice(off, end),
          });
          try { data = await res.json(); } catch (_) { /* none */ }
        } catch (_) {
          if (++tries > 5) throw new Error(`Connection lost while uploading ${f.name}`);
          await sleep(1000 * tries);
          continue;
        }
        if (res.status === 401) {
          toLock("Your session ended. Sign in again.");
          throw new AuthError();
        }
        if (res.status === 409 && data && typeof data.have === "number") {
          done += data.have - off;
          off = data.have;
          continue;
        }
        if (!res.ok) throw new Error(detail(data) || `Upload failed (${res.status})`);
        tries = 0;
        done += end - off;
        off = end;
        alBump();
        upd(i);
        if (data && data.done) { okCount++; break; }
      }
    }
    fill.className = "bar-fill";
    fill.style.width = "100%";
    $("uploadPct").textContent = "100%";
    $("uploadText").textContent = `Uploaded ${okCount} file${okCount === 1 ? "" : "s"}`;
  } catch (e) {
    fail(e);
  } finally {
    S.uploading = false;
    setTimeout(() => { w.hidden = true; }, 2000);
    if (S.label === label && S.path === path && !$("browser").hidden) {
      loadDir(label, path).catch(fail);
    }
  }
}

/* ---------- Viewer ---------- */
const PREVIEW_EXT = new Set(["heic", "heif", "tif", "tiff", "bmp"]);
const isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent);

function mediaUrl(m) {
  const full = joinPath(S.path, m.name);
  const ext = m.name.split(".").pop().toLowerCase();
  const safariNative = isSafari && (ext === "heic" || ext === "heif");
  if (m.kind === "image" && PREVIEW_EXT.has(ext) && !safariNative) return vurl("preview", { path: full });
  return vurl("file", { path: full });
}

function glyphEl(ch) {
  const g = document.createElement("span");
  g.className = "glyph";
  g.textContent = ch;
  return g;
}

function openViewerUI(i) {
  S.vIdx = i;
  const m = S.media[i];
  const v = $("viewer");
  v.hidden = false;
  v.classList.remove("chrome-off");
  document.body.style.overflow = "hidden";
  const st = $("viewerStage");
  for (const old of st.querySelectorAll("video, audio")) { old.pause(); old.removeAttribute("src"); old.load(); }
  st.replaceChildren();
  let el;
  if (m.kind === "image") {
    el = document.createElement("img");
    el.alt = m.name;
    el.addEventListener("error", () => {
      st.replaceChildren(glyphEl("🖼️"));
      toast("This image format cannot be shown here. Download it instead.", true);
    });
  } else if (m.kind === "video") {
    el = document.createElement("video");
    el.controls = true;
    el.playsInline = true;
    el.preload = "metadata";
  } else {
    el = document.createElement("audio");
    el.controls = true;
    el.preload = "metadata";
  }
  el.src = mediaUrl(m);
  st.append(el);
  $("viewerName").textContent = m.name;
  $("viewerPos").textContent = `${i + 1} / ${S.media.length}`;
  const dl = $("viewerDownload");
  dl.href = vurl("file", { path: joinPath(S.path, m.name), download: 1 });
  dl.setAttribute("download", m.name);
  $("viewerPrev").disabled = i === 0;
  $("viewerNext").disabled = i === S.media.length - 1;
  for (const j of [i - 1, i + 1]) {
    const n = S.media[j];
    if (n && n.kind === "image") { const im = new Image(); im.src = mediaUrl(n); }
  }
}

function closeViewerUI() {
  const v = $("viewer");
  if (v.hidden) return;
  for (const m of v.querySelectorAll("video, audio")) { m.pause(); m.removeAttribute("src"); m.load(); }
  $("viewerStage").replaceChildren();
  v.hidden = true;
  document.body.style.overflow = "";
  S.vIdx = -1;
}

function viewerGo(d) {
  const j = S.vIdx + d;
  if (j < 0 || j >= S.media.length) return;
  history.replaceState({ screen: "browser", label: S.label, path: S.path, viewer: j }, "");
  openViewerUI(j);
}

function viewerExit() {
  const st = history.state;
  if (st && st.viewer != null) history.back();
  else closeViewerUI();
}

$("viewerClose").addEventListener("click", viewerExit);
$("viewerPrev").addEventListener("click", () => viewerGo(-1));
$("viewerNext").addEventListener("click", () => viewerGo(1));
$("viewerDelete").addEventListener("click", async () => {
  const idx = S.vIdx;
  const m = S.media[idx];
  if (!m) return;
  const ok = await deleteNames([m.name]);
  if (!ok) return;
  if (!S.media.length) { viewerExit(); return; }
  const j = Math.min(idx, S.media.length - 1);
  history.replaceState({ screen: "browser", label: S.label, path: S.path, viewer: j }, "");
  openViewerUI(j);
});

(() => {
  const st = $("viewerStage");
  let x0 = null;
  let y0 = 0;
  let t0 = 0;
  let multi = false;
  st.addEventListener("touchstart", (e) => {
    if (e.touches.length > 1) { multi = true; return; }
    multi = false;
    x0 = e.touches[0].clientX;
    y0 = e.touches[0].clientY;
    t0 = Date.now();
  }, { passive: true });
  st.addEventListener("touchend", (e) => {
    if (multi || x0 === null) return;
    if (window.visualViewport && window.visualViewport.scale > 1.05) { x0 = null; return; }
    const t = e.changedTouches[0];
    const dx = t.clientX - x0;
    const dy = t.clientY - y0;
    x0 = null;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) viewerGo(dx < 0 ? 1 : -1);
    else if (dy > 100 && Math.abs(dy) > Math.abs(dx) * 1.5) viewerExit();
    else if (Math.abs(dx) < 10 && Math.abs(dy) < 10 && Date.now() - t0 < 300 && e.target.tagName === "IMG") {
      $("viewer").classList.toggle("chrome-off");
    }
  }, { passive: true });
})();

document.addEventListener("keydown", (e) => {
  if ($("viewer").hidden || $("dialog").open) return;
  if (e.key === "ArrowLeft") viewerGo(-1);
  else if (e.key === "ArrowRight") viewerGo(1);
  else if (e.key === "Escape") viewerExit();
});

/* ---------- Auto-lock countdown ---------- */
const AL = { minutes: 60, deadline: 0, lastPoll: 0 };
const alActive = () => $("lock").hidden;

function alBump() {
  if (AL.deadline) AL.deadline = Date.now() + AL.minutes * 60000;
}

async function alPoll() {
  if (!alActive()) return;
  AL.lastPoll = Date.now();
  try {
    const d = await api("GET", "/api/autolock");
    AL.minutes = d.minutes;
    AL.deadline = Date.now() + d.remaining * 1000;
    alTick();
  } catch (_) { /* a 401 already shows the lock screen */ }
}

function alTick() {
  const bar = $("autolockBar");
  if (!alActive() || !AL.deadline) { bar.hidden = true; return; }
  const rem = Math.max(0, Math.ceil((AL.deadline - Date.now()) / 1000));
  if (rem > 60) { bar.hidden = true; return; }
  bar.hidden = false;
  $("alText").textContent = rem > 0 ? "CryptoCloud locks automatically in" : "Locking…";
  $("alSecs").textContent = `${rem} s`;
  $("alFill").style.width = `${(rem / 60) * 100}%`;
  if (rem === 0 && Date.now() - AL.lastPoll > 3000) alPoll();
}

setInterval(alTick, 1000);
setInterval(() => {
  if (!alActive()) return;
  const rem = (AL.deadline - Date.now()) / 1000;
  if (!AL.deadline || rem < 90 || Date.now() - AL.lastPoll > 20000) alPoll();
}, 5000);

$("alStop").addEventListener("click", async () => {
  try {
    const d = await api("POST", "/api/autolock/stop");
    AL.minutes = d.minutes;
    AL.deadline = Date.now() + d.remaining * 1000;
    alTick();
    toast(`Auto-lock restarted: ${d.minutes} minutes`);
  } catch (e) {
    fail(e);
  }
});

$("autolockBtn").addEventListener("click", async () => {
  let cur = AL.minutes;
  try {
    cur = (await api("GET", "/api/autolock")).minutes;
  } catch (e) {
    if (e instanceof AuthError) return;
  }
  const ok = await ask({
    title: "Auto-lock",
    lead: `CryptoCloud locks itself after this many minutes without activity on any device. A countdown appears one minute before. Currently ${cur} minutes.`,
    fields: [{ name: "minutes", label: "Lock after (minutes)", type: "number", value: String(cur),
      hint: "From 5 to 120 minutes" }],
    ok: "Save",
    busy: "Saving…",
    submit: async (f) => {
      const m = Number(f.minutes);
      if (!Number.isInteger(m) || m < 5 || m > 120) throw new Error("Choose a whole number from 5 to 120");
      const d = await api("POST", "/api/autolock", { minutes: m });
      AL.minutes = d.minutes;
      AL.deadline = Date.now() + d.remaining * 1000;
      S.created = d.minutes;
    },
  });
  if (ok) toast(`Auto-lock set to ${S.created} minutes`);
});

/* ---------- Start ---------- */
(async function init() {
  try {
    const st = await api("GET", "/api/state");
    if (!st.authed) {
      toLock(st.master ? "Enter the master password" : "CryptoCloud is locked. The master password unlocks it.");
      return;
    }
    const s = history.state && history.state.screen ? history.state : { screen: "vaults" };
    history.replaceState(s, "");
    await route(s);
    alPoll();
  } catch (e) {
    if (e instanceof AuthError) return;
    toLock();
    $("loginMsg").textContent = "The server cannot be reached right now.";
  }
})();
