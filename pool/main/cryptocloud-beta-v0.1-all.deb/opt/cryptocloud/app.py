"""
CryptoCloud web backend - cryptocloud.space
Runs as user 'cryptocloud' (1 uvicorn worker, 127.0.0.1:8765, behind Apache).
All privileged work goes through /usr/local/sbin/cryptocloud-helper via sudo.
Passwords are never stored on disk: only salted scrypt hashes in RAM.
"""
import asyncio
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import shutil
import time
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import quote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool

# -- Config ----------------------------------------------------
HELPER = ["sudo", "-n", "/usr/local/sbin/cryptocloud-helper"]
MASTER = ""   # no config file = not set up
CONF_FILE = Path("/etc/cryptocloud/cryptocloud.conf")
RUNBASE = Path("/run/cryptocloud/base")


def read_conf():
    conf = {}
    try:
        for line in CONF_FILE.read_text().splitlines():
            m = re.match(r'^([A-Z_]+)="?([^"]*)"?\s*$', line)
            if m:
                conf[m.group(1)] = m.group(2)
    except OSError:
        pass
    return conf


CONF = read_conf()
MODE = CONF.get("MODE", "legacy")
COOKIE_SECURE = CONF.get("COOKIE_SECURE", "1") != "0"


def master():
    """Path of the master gocryptfs mount for the current mode."""
    if MODE == "web":
        return CONF.get("BASE", "").rstrip("/") + "/foldervault"
    if MODE == "offline":
        try:
            base = RUNBASE.read_text().strip()
        except OSError:
            return ""                                   # storage not mounted (yet)
        return base.rstrip("/") + "/foldervault" if base else ""
    return MASTER


def storage_ok():
    m = master()
    return bool(m) and os.path.isdir(os.path.dirname(m) + "/.foldervault.cipher")
STATIC = Path(__file__).parent / "static"
COOKIE = "cc_session"
IDLE_TIMEOUT = 2 * 3600          # seconds of inactivity
ABS_TIMEOUT = 24 * 3600          # max session lifetime
MAX_CHUNK = 16 * 1024 * 1024     # upload chunk limit
THUMB = 360
PREVIEW = 2048
LABEL_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
SIZE_RE = re.compile(r"^[0-9]+[MG]$")
UPID_RE = re.compile(r"^[A-Za-z0-9]{8,40}$")
SETTINGS_FILE = Path("/var/lib/cryptocloud/settings.json")
AUTOLOCK_DEFAULT = 60            # minutes
AUTOLOCK_MIN, AUTOLOCK_MAX = 5, 120

IMG = {"jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif", "tif", "tiff", "svg"}
VID = {"mp4", "m4v", "mov", "webm", "mkv", "avi", "3gp"}
AUD = {"mp3", "m4a", "aac", "ogg", "opus", "flac", "wav"}
TXT = {"txt", "md", "markdown", "log", "conf", "cfg", "ini", "json", "yml", "yaml", "toml",
       "xml", "csv", "tsv", "sh", "bash", "py", "js", "ts", "css", "html", "htm", "c", "h",
       "cpp", "go", "rs", "java", "lua", "sql", "nfo", "srt", "vtt", "env", "list", "service"}
MAX_TEXT = 5 * 1024 * 1024
# ImageMagick 7 has "magick"; IM6 (Ubuntu 22.04/24.04) only "convert"
MAGICK = ["magick"] if shutil.which("magick") else ["convert"]
NEEDS_PREVIEW = {"heic", "heif", "tif", "tiff", "bmp"}
for ext, mt in {".mov": "video/quicktime", ".mkv": "video/x-matroska", ".heic": "image/heic",
                ".heif": "image/heif", ".avif": "image/avif", ".webp": "image/webp",
                ".m4a": "audio/mp4", ".opus": "audio/ogg", ".flac": "audio/flac"}.items():
    mimetypes.add_type(mt, ext)

# -- In-memory state (gone on restart/reboot) -------------------
master_hash = None               # (salt, hash)
vault_hashes = {}                # label -> (salt, hash)
mounts = {}                      # label -> mount path
sessions = {}                    # token -> {created, seen, vaults:set}
fails = {}                       # ip -> {count, until}
thumb_sem = asyncio.Semaphore(2)
activity = {"last": None}        # last real user activity while the master is unlocked


def load_settings():
    s = {"autolock_min": AUTOLOCK_DEFAULT}
    try:
        data = json.loads(SETTINGS_FILE.read_text())
        m = int(data.get("autolock_min", AUTOLOCK_DEFAULT))
        if AUTOLOCK_MIN <= m <= AUTOLOCK_MAX:
            s["autolock_min"] = m
    except (OSError, ValueError, TypeError):
        pass
    return s


def save_settings():
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = SETTINGS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(settings))
    os.replace(tmp, SETTINGS_FILE)


settings = load_settings()


def touch():
    activity["last"] = time.time()


def autolock_remaining():
    if activity["last"] is None:
        touch()
    return max(0, int(activity["last"] + settings["autolock_min"] * 60 - time.time()))


async def autolock_loop():
    n = 0
    while True:
        await asyncio.sleep(10)
        n += 1
        try:
            # offline mode: keep trying to find the storage disk (every 30 s)
            if MODE == "offline" and not storage_ok() and n % 3 == 0:
                await try_storage_mount()
            if not os.path.ismount(master()):
                activity["last"] = None
                continue
            if autolock_remaining() > 0:
                continue
            r = await helper("master-lock")
            if r.get("ok"):
                wipe_all()
                activity["last"] = None
                print(f"[cryptocloud] auto-locked after {settings['autolock_min']} min of inactivity", flush=True)
            else:
                print(f"[cryptocloud] auto-lock failed: {r.get('error')}", flush=True)
        except Exception as e:  # keep the loop alive no matter what
            print(f"[cryptocloud] auto-lock loop error: {e}", flush=True)


@asynccontextmanager
async def lifespan(_app):
    task = asyncio.create_task(autolock_loop())
    try:
        yield
    finally:
        task.cancel()


app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    h = resp.headers
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "no-referrer"
    h["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; "
        "style-src 'self'; script-src 'self'; connect-src 'self'; "
        "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
    if request.url.path.startswith("/api/"):
        h["Cache-Control"] = "no-store"
    return resp


# -- Helpers ---------------------------------------------------
def kdf(pw: str, salt: bytes) -> bytes:
    return hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)


async def mk_hash(pw):
    salt = os.urandom(16)
    return salt, await run_in_threadpool(kdf, pw, salt)


async def check_hash(h, pw):
    return hmac.compare_digest(await run_in_threadpool(kdf, pw, h[0]), h[1])


def check_pw_format(pw: str):
    if not pw or "\n" in pw or "\r" in pw or len(pw) > 1024:
        raise HTTPException(400, "Invalid password")


async def helper(*args, pw=None, timeout=300):
    proc = await asyncio.create_subprocess_exec(
        *HELPER, *args, stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    data_in = (pw + "\n").encode() if pw is not None else b""
    try:
        out, err = await asyncio.wait_for(proc.communicate(data_in), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return {"ok": False, "error": "operation timed out", "_rc": -1}
    try:
        data = json.loads(out.decode().strip().splitlines()[-1])
    except Exception:
        data = {"ok": False, "error": (err or out).decode(errors="replace")[-200:] or "helper error"}
    data["_rc"] = proc.returncode
    return data


def client_ip(req: Request) -> str:
    return req.client.host if req.client else "unknown"


def throttle_check(ip):
    f = fails.get(ip)
    if f and f["until"] > time.time():
        wait = int(f["until"] - time.time()) + 1
        raise HTTPException(429, f"Too many wrong attempts. Try again in {wait} s.")


def throttle_fail(ip):
    f = fails.setdefault(ip, {"count": 0, "until": 0})
    f["count"] += 1
    if f["count"] >= 5:
        f["until"] = time.time() + min(30 * 2 ** (f["count"] - 5), 3600)


def throttle_ok(ip):
    fails.pop(ip, None)


def wipe_all():
    global master_hash
    master_hash = None
    vault_hashes.clear()
    mounts.clear()
    sessions.clear()


def get_session(req: Request, keepalive: bool = True):
    if not os.path.ismount(master()):
        wipe_all()
        raise HTTPException(401, "CryptoCloud is locked")
    tok = req.cookies.get(COOKIE)
    s = sessions.get(tok) if tok else None
    now = time.time()
    if not s or now - s["seen"] > IDLE_TIMEOUT or now - s["created"] > ABS_TIMEOUT:
        sessions.pop(tok, None)
        raise HTTPException(401, "Sign in required")
    if keepalive:
        s["seen"] = now
        touch()
    return s


async def status():
    r = await helper("status")
    if not r.get("ok"):
        raise HTTPException(500, r.get("error", "status failed"))
    for v in r.get("vaults", []):
        mounts[v["label"]] = v["mount"]
    return r


async def vault_root(s, label) -> Path:
    """A mounted vault is open to every signed-in session until it is closed."""
    if not LABEL_RE.match(label):
        raise HTTPException(400, "Invalid vault")
    m = mounts.get(label)
    if not m or not os.path.ismount(m):
        await status()                      # refresh cache (e.g. after app restart)
        m = mounts.get(label)
    if not m or not os.path.ismount(m):
        raise HTTPException(403, "This vault is locked")
    return Path(m)


def resolve(root: Path, rel: str) -> Path:
    parts = [p for p in (rel or "").split("/") if p]
    for p in parts:
        if p in (".", "..") or p.startswith("."):
            raise HTTPException(400, "Invalid path")
    p = root.joinpath(*parts)
    real = Path(os.path.realpath(p))
    if real != root and root not in real.parents:
        raise HTTPException(400, "Invalid path")
    return p


def check_name(name: str):
    if (not name or "/" in name or "\x00" in name or name.startswith(".")
            or len(name.encode()) > 255):
        raise HTTPException(400, "Invalid name")


def kind_of(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext in IMG:
        return "image"
    if ext in VID:
        return "video"
    if ext in AUD:
        return "audio"
    if ext in TXT:
        return "text"
    return "file"


def natkey(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def unique_path(d: Path, name: str) -> Path:
    p = d / name
    if not p.exists():
        return p
    stem, dot, ext = name.rpartition(".")
    if not dot or not stem:
        stem, ext = name, ""
    i = 1
    while True:
        cand = d / (f"{stem} ({i}).{ext}" if ext else f"{stem} ({i})")
        if not cand.exists():
            return cand
        i += 1


def ranged(path: Path, req: Request, attachment=False):
    size = path.stat().st_size
    media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    disp = "attachment" if attachment else "inline"
    headers = {"Accept-Ranges": "bytes", "Cache-Control": "no-store",
               "Content-Disposition": f"{disp}; filename*=UTF-8''{quote(path.name)}"}
    start, end, code = 0, size - 1, 200
    rng = req.headers.get("range")
    if rng:
        m = re.match(r"^bytes=(\d*)-(\d*)$", rng.strip())
        if m:
            a, b = m.groups()
            if a == "" and b:
                start = max(0, size - int(b))
            else:
                start = int(a or 0)
                end = min(int(b), size - 1) if b else size - 1
            if start > end or start >= size:
                return Response(status_code=416, headers={"Content-Range": f"bytes */{size}"})
            code = 206
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    length = max(0, end - start + 1)
    headers["Content-Length"] = str(length)

    def gen():
        with open(path, "rb") as f:
            f.seek(start)
            remaining = length
            while remaining > 0:
                chunk = f.read(min(1 << 20, remaining))
                if not chunk:
                    break
                remaining -= len(chunk)
                yield chunk

    return StreamingResponse(gen(), status_code=code, headers=headers, media_type=media_type)


# -- Models ----------------------------------------------------
class PwBody(BaseModel):
    password: str


class CreateBody(BaseModel):
    label: str
    size: str
    password: str


class MkdirBody(BaseModel):
    path: str = ""
    name: str


class RenameBody(BaseModel):
    path: str
    name: str


class DeleteBody(BaseModel):
    paths: list[str]


class DestroyBody(BaseModel):
    password: str
    confirm: str


class GrowBody(BaseModel):
    size: str
    password: str


class PasswdBody(BaseModel):
    old: str
    new: str


# -- Auth ------------------------------------------------------
@app.get("/api/state")
async def api_state(req: Request):
    unlocked = os.path.ismount(master())
    authed = False
    if unlocked:
        tok = req.cookies.get(COOKIE)
        s = sessions.get(tok) if tok else None
        authed = bool(s and time.time() - s["seen"] <= IDLE_TIMEOUT
                      and time.time() - s["created"] <= ABS_TIMEOUT)
    out = {"master": unlocked, "authed": authed, "mode": MODE, "storage": storage_ok()}
    if MODE == "offline" and not out["storage"]:
        out["storage_uuid"] = CONF.get("STORAGE_UUID", "")
        out["storage_path"] = CONF.get("STORAGE_PATH", "")
    return out


_last_mount_try = {"t": 0.0}


async def try_storage_mount():
    """Offline mode: ask the helper to find and mount the storage disk."""
    if MODE != "offline" or storage_ok():
        return {"ok": True, "storage": True}
    if time.time() - _last_mount_try["t"] < 5:
        return {"ok": False, "storage": False, "error": "Retrying too fast, wait a few seconds"}
    _last_mount_try["t"] = time.time()
    r = await helper("storage-mount", timeout=60)
    return {"ok": bool(r.get("ok")), "storage": storage_ok(), "error": r.get("error", "")}


@app.post("/api/storage/mount")
async def api_storage_mount():
    # No secrets involved: only (re)mounts the configured storage disk
    return await try_storage_mount()


@app.post("/api/login")
async def api_login(req: Request, body: PwBody):
    global master_hash
    ip = client_ip(req)
    throttle_check(ip)
    pw = body.password
    check_pw_format(pw)
    if not os.path.ismount(master()):
        if MODE == "offline" and not storage_ok():
            await try_storage_mount()
        r = await helper("master-unlock", pw=pw)
        if not r.get("ok"):
            if r["_rc"] == 2:
                throttle_fail(ip)
                raise HTTPException(401, "Wrong password")
            if r["_rc"] == 6:
                raise HTTPException(503, r.get("error", "Storage offline"))
            raise HTTPException(500, r.get("error", "Unlock failed"))
        wipe_all()
        master_hash = await mk_hash(pw)
    else:
        if master_hash:
            good = await check_hash(master_hash, pw)
        else:
            r = await helper("verify-master", pw=pw)
            good = bool(r.get("ok"))
            if good:
                master_hash = await mk_hash(pw)
        if not good:
            throttle_fail(ip)
            raise HTTPException(401, "Wrong password")
    throttle_ok(ip)
    touch()
    tok = secrets.token_urlsafe(32)
    now = time.time()
    sessions[tok] = {"created": now, "seen": now, "vaults": set()}
    resp = JSONResponse({"ok": True})
    resp.set_cookie(COOKIE, tok, httponly=True, secure=COOKIE_SECURE, samesite="strict", path="/")
    return resp


@app.post("/api/logout")
async def api_logout(req: Request):
    sessions.pop(req.cookies.get(COOKIE, ""), None)
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(COOKIE, path="/")
    return resp


@app.post("/api/lock")
async def api_lock(req: Request):
    get_session(req)
    r = await helper("master-lock")
    wipe_all()
    if not r.get("ok"):
        raise HTTPException(500, r.get("error", "Lock failed"))
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(COOKIE, path="/")
    return resp


# -- Auto-lock -------------------------------------------------
class AutolockBody(BaseModel):
    minutes: int


@app.get("/api/autolock")
async def api_autolock(req: Request):
    get_session(req, keepalive=False)      # polling must not count as activity
    return {"minutes": settings["autolock_min"], "remaining": autolock_remaining()}


@app.post("/api/autolock/stop")
async def api_autolock_stop(req: Request):
    get_session(req)                        # counts as activity: timer restarts
    return {"minutes": settings["autolock_min"], "remaining": autolock_remaining()}


@app.post("/api/autolock")
async def api_autolock_set(req: Request, body: AutolockBody):
    get_session(req)
    if not AUTOLOCK_MIN <= body.minutes <= AUTOLOCK_MAX:
        raise HTTPException(400, f"Choose between {AUTOLOCK_MIN} and {AUTOLOCK_MAX} minutes")
    settings["autolock_min"] = body.minutes
    await run_in_threadpool(save_settings)
    return {"minutes": settings["autolock_min"], "remaining": autolock_remaining()}


# -- Vaults ----------------------------------------------------
@app.get("/api/vaults")
async def api_vaults(req: Request):
    s = get_session(req)
    r = await status()
    out = []
    for v in r.get("vaults", []):
        out.append({"label": v["label"], "size": v["size"],
                    "open": bool(v["open"] or v["mounted"]),
                    "unlocked": bool(v["mounted"])})
    out.sort(key=lambda v: natkey(v["label"]))
    return {"budget_mb": r.get("budget_mb", 0), "used_mb": r.get("used_mb", 0), "vaults": out}


@app.post("/api/vaults")
async def api_create(req: Request, body: CreateBody):
    s = get_session(req)
    if not LABEL_RE.match(body.label):
        raise HTTPException(400, "Name: lowercase letters, digits and dashes, max 32")
    if not SIZE_RE.match(body.size):
        raise HTTPException(400, "Invalid size")
    check_pw_format(body.password)
    if len(body.password) < 8:
        raise HTTPException(400, "Vault password must be at least 8 characters")
    r = await helper("create", body.label, body.size, pw=body.password)
    if not r.get("ok"):
        raise HTTPException(400, r.get("error", "Create failed"))
    vault_hashes[body.label] = await mk_hash(body.password)
    mounts[body.label] = r["mount"]
    s["vaults"].add(body.label)
    return {"ok": True, "label": body.label}


@app.post("/api/vaults/{label}/open")
async def api_open(req: Request, label: str, body: PwBody):
    s = get_session(req)
    if not LABEL_RE.match(label):
        raise HTTPException(400, "Invalid vault")
    r = await status()
    v = next((x for x in r.get("vaults", []) if x["label"] == label), None)
    if not v:
        raise HTTPException(404, "No such vault")
    if v["mounted"]:
        # Already open on the server: available to every signed-in device
        mounts[label] = v["mount"]
        s["vaults"].add(label)
        return {"ok": True, "already": True}
    ip = client_ip(req)
    throttle_check(ip)
    check_pw_format(body.password)
    if v["mounted"]:
        h = vault_hashes.get(label)
        if h:
            good = await check_hash(h, body.password)
        else:
            good = bool((await helper("verify", label, pw=body.password)).get("ok"))
    else:
        o = await helper("open", label, pw=body.password)
        good = bool(o.get("ok"))
        if not good and o["_rc"] != 2:
            raise HTTPException(500, o.get("error", "Open failed"))
    if not good:
        throttle_fail(ip)
        raise HTTPException(403, "Wrong vault password")
    throttle_ok(ip)
    if label not in vault_hashes:
        vault_hashes[label] = await mk_hash(body.password)
    mounts[label] = v["mount"]
    s["vaults"].add(label)
    return {"ok": True}


@app.post("/api/vaults/{label}/close")
async def api_close(req: Request, label: str):
    s = get_session(req)
    await vault_root(s, label)
    r = await helper("close", label)
    if not r.get("ok"):
        raise HTTPException(409 if r["_rc"] == 5 else 500,
                            "The vault is still in use and could not be closed. Try again in a moment."
                            if r["_rc"] == 5 else r.get("error", "Close failed"))
    vault_hashes.pop(label, None)
    for sess in sessions.values():
        sess["vaults"].discard(label)
    return {"ok": True}


# -- Vault admin -----------------------------------------------------
@app.post("/api/vaults/{label}/destroy")
async def api_destroy(req: Request, label: str, body: DestroyBody):
    get_session(req)
    if not LABEL_RE.match(label):
        raise HTTPException(400, "Invalid vault")
    if body.confirm.strip() != label:
        raise HTTPException(400, f"Type {label} exactly to confirm")
    ip = client_ip(req)
    throttle_check(ip)
    check_pw_format(body.password)
    r = await helper("delete", label, pw=body.password)
    if not r.get("ok"):
        rc = r["_rc"]
        if rc == 2:
            throttle_fail(ip)
            raise HTTPException(403, "Wrong vault password")
        if rc == 4:
            raise HTTPException(404, "No such vault")
        if rc == 5:
            raise HTTPException(409, "The vault is still in use. Try again in a moment.")
        raise HTTPException(500, r.get("error", "Delete failed"))
    throttle_ok(ip)
    vault_hashes.pop(label, None)
    mounts.pop(label, None)
    for sess in sessions.values():
        sess["vaults"].discard(label)
    return {"ok": True}


@app.post("/api/vaults/{label}/grow")
async def api_grow(req: Request, label: str, body: GrowBody):
    s = get_session(req)
    if not LABEL_RE.match(label):
        raise HTTPException(400, "Invalid vault")
    if not SIZE_RE.match(body.size):
        raise HTTPException(400, "Invalid size")
    ip = client_ip(req)
    throttle_check(ip)
    check_pw_format(body.password)
    r = await helper("grow", label, body.size, pw=body.password)
    if not r.get("ok"):
        rc = r["_rc"]
        if rc == 2:
            throttle_fail(ip)
            raise HTTPException(403, "Wrong vault password")
        if rc == 4:
            raise HTTPException(404, "No such vault")
        if rc == 5:
            raise HTTPException(409, "The vault is still in use. Try again in a moment.")
        raise HTTPException(400, r.get("error", "Grow failed"))
    throttle_ok(ip)
    mounts[label] = r["mount"]
    vault_hashes[label] = await mk_hash(body.password)
    s["vaults"].add(label)
    return {"ok": True, "size": r.get("size")}


@app.post("/api/vaults/{label}/passwd")
async def api_passwd(req: Request, label: str, body: PasswdBody):
    get_session(req)
    if not LABEL_RE.match(label):
        raise HTTPException(400, "Invalid vault")
    check_pw_format(body.old)
    check_pw_format(body.new)
    if len(body.new) < 8:
        raise HTTPException(400, "The new password needs at least 8 characters")
    ip = client_ip(req)
    throttle_check(ip)
    r = await helper("passwd", label, pw=f"{body.old}\n{body.new}")
    if not r.get("ok"):
        if r["_rc"] == 2:
            throttle_fail(ip)
            raise HTTPException(403, "Wrong current password")
        if r["_rc"] == 4:
            raise HTTPException(404, "No such vault")
        raise HTTPException(400, r.get("error", "Password change failed"))
    throttle_ok(ip)
    vault_hashes[label] = await mk_hash(body.new)
    return {"ok": True}


@app.post("/api/vaults/{label}/save")
async def api_save(req: Request, label: str, path: str, create: int = 0):
    s = get_session(req)
    root = await vault_root(s, label)
    target = resolve(root, path)
    if target == root:
        raise HTTPException(400, "Invalid path")
    check_name(target.name)
    if not target.parent.is_dir():
        raise HTTPException(404, "Folder not found")
    if create and target.exists():
        raise HTTPException(409, "A file with that name already exists")
    if not create and not target.is_file():
        raise HTTPException(404, "File not found")
    data = b""
    async for chunk in req.stream():
        data += chunk
        if len(data) > MAX_TEXT:
            raise HTTPException(413, "Text files are limited to 5 MB")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(400, "Text must be UTF-8")

    def write():
        tmp = target.parent / f".cc-save-{secrets.token_hex(8)}.part"
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)
        st = target.stat()
        return {"ok": True, "size": st.st_size, "mtime": int(st.st_mtime)}

    return await run_in_threadpool(write)


# -- Files -----------------------------------------------------
@app.get("/api/vaults/{label}/list")
async def api_list(req: Request, label: str, path: str = ""):
    s = get_session(req)
    root = await vault_root(s, label)
    d = resolve(root, path)
    if not d.is_dir():
        raise HTTPException(404, "Folder not found")

    def scan():
        entries, now = [], time.time()
        with os.scandir(d) as it:
            for e in it:
                if e.name.startswith(".cc-up-"):
                    try:
                        if now - e.stat().st_mtime > 86400:
                            os.unlink(e.path)
                    except OSError:
                        pass
                    continue
                if e.name.startswith(".") or e.is_symlink():
                    continue
                st = e.stat()
                isdir = e.is_dir()
                entries.append({"name": e.name, "dir": isdir,
                                "size": 0 if isdir else st.st_size,
                                "mtime": int(st.st_mtime),
                                "kind": "dir" if isdir else kind_of(e.name)})
        entries.sort(key=lambda x: (not x["dir"], natkey(x["name"])))
        du = shutil.disk_usage(root)
        return {"path": path.strip("/"), "entries": entries,
                "space": {"total": du.total, "used": du.used, "free": du.free}}

    return await run_in_threadpool(scan)


@app.get("/api/vaults/{label}/file")
async def api_file(req: Request, label: str, path: str, download: int = 0):
    s = get_session(req)
    p = resolve(await vault_root(s, label), path)
    if not p.is_file():
        raise HTTPException(404, "File not found")
    return ranged(p, req, attachment=bool(download))


async def run_tool(args, env=None, timeout=120):
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL, env=env)
    try:
        return await asyncio.wait_for(proc.wait(), timeout) == 0
    except asyncio.TimeoutError:
        proc.kill()
        return False


async def render_image(root: Path, src: Path, prefix: str, box: int, crop: bool):
    st = src.stat()
    key = hashlib.sha1(f"{src.relative_to(root)}|{st.st_mtime_ns}|{st.st_size}|{box}".encode()).hexdigest()
    tdir = root / ".thumbs"
    out = tdir / f"{prefix}{key}.jpg"
    if out.exists():
        return out
    tmpdir = tdir / "tmp"
    tmpdir.mkdir(parents=True, exist_ok=True)
    part = tdir / f".{prefix}{key}.part.jpg"
    env = dict(os.environ, MAGICK_TEMPORARY_PATH=str(tmpdir), TMPDIR=str(tmpdir))
    kind = kind_of(src.name)
    async with thumb_sem:
        if out.exists():
            return out
        if kind == "video":
            vf = (f"scale={box}:{box}:force_original_aspect_ratio=increase,crop={box}:{box}"
                  if crop else f"scale={box}:{box}:force_original_aspect_ratio=decrease")
            ok = False
            for ss in ("1", "0"):
                ok = await run_tool(["ffmpeg", "-v", "error", "-ss", ss, "-i", str(src),
                                     "-frames:v", "1", "-vf", vf, "-q:v", "5", "-y", str(part)], env)
                if ok and part.exists() and part.stat().st_size > 0:
                    break
        elif kind == "image":
            geo = ["-thumbnail", f"{box}x{box}^", "-gravity", "center", "-extent", f"{box}x{box}"] \
                if crop else ["-resize", f"{box}x{box}>"]
            ok = await run_tool([*MAGICK, f"{src}[0]", "-auto-orient", *geo,
                                 "-strip", "-quality", "78", f"jpg:{part}"], env)
        else:
            ok = False
        if not ok or not part.exists():
            part.unlink(missing_ok=True)
            return None
        os.replace(part, out)
        return out


@app.get("/api/vaults/{label}/thumb")
async def api_thumb(req: Request, label: str, path: str):
    s = get_session(req)
    root = await vault_root(s, label)
    p = resolve(root, path)
    if not p.is_file():
        raise HTTPException(404, "File not found")
    out = await render_image(root, p, "t-", THUMB, True)
    if not out:
        raise HTTPException(404, "No thumbnail")
    return ranged(out, req)


@app.get("/api/vaults/{label}/preview")
async def api_preview(req: Request, label: str, path: str):
    s = get_session(req)
    root = await vault_root(s, label)
    p = resolve(root, path)
    if not p.is_file():
        raise HTTPException(404, "File not found")
    out = await render_image(root, p, "p-", PREVIEW, False)
    if not out:
        raise HTTPException(404, "No preview")
    return ranged(out, req)


@app.post("/api/vaults/{label}/upload")
async def api_upload(req: Request, label: str, name: str, offset: int, total: int,
                     id: str, path: str = ""):
    s = get_session(req)
    root = await vault_root(s, label)
    d = resolve(root, path)
    if not d.is_dir():
        raise HTTPException(404, "Folder not found")
    check_name(name)
    if not UPID_RE.match(id) or offset < 0 or total < 0 or offset > total:
        raise HTTPException(400, "Invalid upload")
    clen = int(req.headers.get("content-length") or 0)
    if clen > MAX_CHUNK:
        raise HTTPException(413, "Chunk too large")
    if shutil.disk_usage(root).free < (total - offset) + 64 * 1024:   # small vaults (2-3 MB) must work
        raise HTTPException(507, "This vault is full")
    part = d / f".cc-up-{id}.part"
    have = part.stat().st_size if part.exists() else 0
    if offset != have:
        return JSONResponse({"ok": False, "have": have}, status_code=409)
    written = 0
    with open(part, "ab") as f:
        async for chunk in req.stream():
            if not chunk:
                continue
            written += len(chunk)
            if offset + written > total or written > MAX_CHUNK:
                f.close()
                part.unlink(missing_ok=True)
                raise HTTPException(400, "Upload larger than announced")
            await run_in_threadpool(f.write, chunk)
    now_have = offset + written
    if now_have == total:
        final = unique_path(d, name)
        os.replace(part, final)
        return {"ok": True, "done": True, "name": final.name}
    return {"ok": True, "done": False, "have": now_have}


@app.post("/api/vaults/{label}/mkdir")
async def api_mkdir(req: Request, label: str, body: MkdirBody):
    s = get_session(req)
    d = resolve(await vault_root(s, label), body.path)
    check_name(body.name)
    target = d / body.name
    if target.exists():
        raise HTTPException(409, "A file or folder with that name already exists")
    target.mkdir()
    return {"ok": True}


@app.post("/api/vaults/{label}/rename")
async def api_rename(req: Request, label: str, body: RenameBody):
    s = get_session(req)
    root = await vault_root(s, label)
    src = resolve(root, body.path)
    if src == root or not src.exists():
        raise HTTPException(404, "Not found")
    check_name(body.name)
    dst = src.parent / body.name
    if dst.exists():
        raise HTTPException(409, "A file or folder with that name already exists")
    os.rename(src, dst)
    return {"ok": True}


@app.post("/api/vaults/{label}/delete")
async def api_delete(req: Request, label: str, body: DeleteBody):
    s = get_session(req)
    root = await vault_root(s, label)
    targets = [resolve(root, p) for p in body.paths]
    if any(t == root for t in targets):
        raise HTTPException(400, "Cannot delete the vault root")

    def work():
        n = 0
        for t in targets:
            if t.is_dir() and not t.is_symlink():
                shutil.rmtree(t)
                n += 1
            elif t.exists() or t.is_symlink():
                t.unlink()
                n += 1
        return n

    return {"ok": True, "deleted": await run_in_threadpool(work)}


# -- Static front end (must be last) ---------------------------
app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
